const Sauce = require('../models/Sauce');
const fs = require('fs'); // Importation du package fs (file system) de Node. Permet d'accéder aux fonctions de modification du système de fichiers

exports.createSauce = (req, res, next) => {
  const sauceObject = JSON.parse(req.body.sauce);
  delete sauceObject._id;
  const sauce = new Sauce({
    ...sauceObject,
    imageUrl: `${req.protocol}://${req.get('host')}/images/${req.file.filename}`, // Résolution complète de l'URL de l'image
    // req.protocol => premier segment, req.get('host') => résolution de l'hôte, dossier images, req.file.filename => nom du fichier
    likes: 0,
    dislikes: 0,
    usersLiked: [],
    usersDisliked: []
  });
  sauce.save()
    .then(() => res.status(201).json({ message: 'Sauce enregistrée' }))
    .catch(error => res.status(400).json({ error }));
};

exports.modifySauce = (req, res, next) => {
  const sauceObject = req.file ? // L'opérateur ternaire permet de traiter 2 cas. L'image a ou n'a pas été modifiée.
    {
      ...JSON.parse(req.body.sauce),
      imageUrl: `${req.protocol}://${req.get('host')}/images/${req.file.filename}`
    } : { ...req.body };
  Sauce.updateOne({ _id: req.params.id }, { ...sauceObject, _id: req.params.id })
    .then(() => res.status(200).json({ message: 'Sauce modifiée' }))
    .catch(error => res.status(400).json({ error }));
};

exports.deleteSauce = (req, res, next) => {
  Sauce.findOne({ _id: req.params.id })
    .then(sauce => { // Mise à jour d'une faille de sécurité: on vérifie que la sauce a bien été créée par l'utilisateur faisant la requête
      if (!sauce) {
        return res.status(404).json({ error: new Error('Objet non trouvé!') });
      }
      if (sauce.userId !== req.auth.userId) {
        return res.status(401).json({ error: new Error('Requête non autorisée!') });
      }
      const filename = sauce.imageUrl.split('/images/')[1]; // Récupération du 2ième élément du tableau créé par split
      fs.unlink(`images/${filename}`, () => {
        Sauce.deleteOne({ _id: req.params.id })
          .then(() => res.status(200).json({ message: 'Sauce supprimée' }))
          .catch(error => res.status(400).json({ error }));
      });
    })
    .catch(error => res.status(500).json({ error }));
};

exports.getOneSauce = (req, res, next) => {
  Sauce.findOne({ _id: req.params.id })
    .then(
      (sauce) => { res.status(200).json(sauce); })
    .catch((error) => { res.status(404).json({ error: error }); });
};

exports.getAllSauces = (req, res, next) => {
  Sauce.find()
    .then(sauces => res.status(200).json(sauces))
    .catch(error => res.status(400).json({ error }));
};

exports.likeOrDislike = (req, res, next) => {

  let like = req.body.like

  let userId = req.body.userId

  let sauceId = req.params.id

  if (like === 1) {
    Sauce.updateOne({ _id: sauceId }, { $push: { usersLiked: userId }, $inc: { likes: +1 } })
      .then(() => res.status(200).json({ message: 'LIKE!' }))
      .catch(error => res.status(400).json({ error }))
  }
  if (like === -1) {
    Sauce.updateOne({ _id: sauceId }, { $push: { usersDisliked: userId }, $inc: { dislikes: +1 } })
      .then(() => res.status(200).json({ message: 'DISLIKE!' }))
      .catch(error => res.status(400).json({ error }))
  }
  if (like === 0) {
    Sauce.findOne({ _id: sauceId })
      .then((sauce) => {
        if (sauce.usersLiked.includes(userId)) {
          Sauce.updateOne({ _id: sauceId }, { $pull: { usersLiked: userId }, $inc: { likes: -1 } })
            .then(() => res.status(200).json({ message: 'LIKE supprimé!' }))
            .catch(error => res.status(400).json({ error }))
        }
        if (sauce.usersDisliked.includes(userId)) {
          Sauce.updateOne({ _id: sauceId }, { $pull: { usersDisliked: userId }, $inc: { dislikes: -1 } })
            .then(() => res.status(200).json({ message: 'DISLIKE supprimé!' }))
            .catch(error => res.status(400).json({ error }))
        }
      })
      .catch(error => res.status(404).json({ error }))
  }
}