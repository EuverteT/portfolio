const express = require('express'); // Permet l'importation du framework Express
const mongoose = require('mongoose');
const path = require('path'); // Permet l'accès au chemin de notre système de fichiers

const saucesRoutes = require('./routes/sauces');
const userRoutes = require('./routes/user');

require('dotenv').config(); // Permet de masquer les informations de connexion à la base de données

mongoose.connect('mongodb+srv://' + process.env.DB_USER + ':' + process.env.DB_PASSWORD + '@cluster0.xurzo.mongodb.net/' + process.env.DB_NAME + '?retryWrites=true&w=majority',
    {
        useNewUrlParser: true,
        useUnifiedTopology: true
    })
    .then(() => console.log('Connexion à MongoDB réussie !'))
    .catch(() => console.log('Connexion à MongoDB échouée !'));

const app = express(); // Permet l'utilisation du framework Express

app.use((req, res, next) => { // Middleware permettant d'éviter les erreurs CORS (Cross Origin Resource Sharing)
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    next();
});

app.use(express.json()); // Permet de ne plus utiliser body-parser qui est inclut à présent dans Express

app.use('/images', express.static(path.join(__dirname, 'images'))); // Signale à Express qu'on utilise les images de manière statique

app.use('/api/sauces', saucesRoutes);
app.use('/api/auth', userRoutes);

module.exports = app;