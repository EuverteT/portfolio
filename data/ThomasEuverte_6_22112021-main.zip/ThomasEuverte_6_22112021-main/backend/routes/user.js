const express = require('express');
const router = express.Router();
const userCtrl = require('../controllers/user'); // Importation du controlleur contenant la logique liée à la création ou connexion d'un compte => logique de routing claire et explicite

router.post('/signup', userCtrl.signup);
router.post('/login', userCtrl.login);

module.exports = router;