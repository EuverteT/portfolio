const express = require('express');
const router = express.Router();

const saucesCtrl = require('../controllers/sauces'); // Importation des controlleurs et middlewares contenant la logique métier => logique de routing claire et explicite
const auth = require('../middleware/auth');
const multer = require('../middleware/multer-config');

router.post('/', auth, multer, saucesCtrl.createSauce); // Requêtes authentifiées même pour l'envoi d'images (également au niveau de la modification d'une sauce)
router.post('/:id/like', auth, saucesCtrl.likeOrDislike);
router.put('/:id', auth, multer, saucesCtrl.modifySauce);
router.delete('/:id', auth, saucesCtrl.deleteSauce);
router.get('/:id', auth, saucesCtrl.getOneSauce);
router.get('/', auth, saucesCtrl.getAllSauces);

module.exports = router;