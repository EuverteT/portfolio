const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

const userSchema = mongoose.Schema({ // Schéma mongoose strict permettant la création d'utilisateur
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

userSchema.plugin(uniqueValidator); // Plugin permettant l'unicité d'une adresse mail pour la création d'un compte

module.exports = mongoose.model('User', userSchema);