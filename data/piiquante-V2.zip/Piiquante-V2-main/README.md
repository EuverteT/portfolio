# PIIQUANTE V2 (2024)

## Construisez une API sécurisée pour une application d'avis gastronomiques

*Projet 6 de la formation Développeur web d'OpenClassRooms.*

Le projet consiste à développer le backend d'une application permettant d'ajouter des sauces afin de les partager avec d'autres utilisateurs. Il est également possible de liker ou disliker les sauces.

Le frontend est fourni et a été développé/compilé à l'aide d'Angular. Il nous est demandé de créer une API en utilisant Node, le framework Express et une base de données afin de stocker les utilisateurs et sauces créés.

Cette version de 2024 a été faite car la version 2021, lorsqu'on l'installe à l'heure actuelle, dispose de certaines failles de sécurité sur certains packages.

## Compétences évaluées

#### La création de cette API permet de:

- Stocker des données de manière sécurisée
- Implémenter un modèle logique de données conformément à la réglementation
- Mettre en œuvre des opérations CRUD de manière sécurisée

## Exigences de sécurité

*Il est primordial de porter une attention particulière sur la sécurité de l'application.*

- Le mot de passe de l'utilisateur doit être haché.
- L'authentification doit être renforcée sur toutes les routes sauce requises.
- Les adresses électroniques dans la base de données sont uniques et un
plugin Mongoose approprié est utilisé pour garantir leur unicité et signaler
les erreurs.
- La sécurité de la base de données MongoDB (à partir d'un service tel que
MongoDB Atlas) ne doit pas empêcher l'application de se lancer sur la
machine d'un utilisateur.
- Un plugin Mongoose doit assurer la remontée des erreurs issues de la base
de données.
- Les versions les plus récentes des logiciels sont utilisées avec des correctifs
de sécurité actualisés.
- Le contenu du dossier images ne doit pas être téléchargé sur GitHub.

## Comment utiliser l'application?

#### Les installations et commandes suivantes sont nécessaires:

- Installer Node, Sass, Npm sur votre poste de travail
- Télécharger le projet compressé au format ZIP et l'extraire
- Extraire les deux dossiers compressés frontend et backend
- Aller dans le frontend (via un terminal) et faire `npm install`
- Faire `npm start` , le serveur se lance sur http://localhost:4200
- Aller dans le backend (via un terminal) et  faire `npm install`
- Toujours dans le dossier backend,  créer un fichier .env avec les données fournies par le développeur (DB_USER, DB_PASSWORD, DB_NAME, TOKEN) (ignoré avec gitignore pour des raisons de sécurité)
- Créer également un dossier /images à la racine (ignoré avec gitignore pour optimiser la taille du projet)
- Faire `node server`(ou nodemon server si celui-ci est installé). La connexion se fait sur le port 3000.

#### Sécurisation de l'application et des données?

- bcryptjs (hash et salage du mot de passe utilisateur)
- jsonwebtoken (sécurisation de l'authentification pour les requêtes )
- mongoose (schémas stricts)
- mongoose-unique-validator (création d'un compte par adresse mail)
- dotenv (sécurisation des informations de connexion et d'accès à la base de données)
- dossier images et dotenv non téléchargés sur github (via gitignore)
- helmet et cookie-session auraient été judicieux et sont préconisés dans les recommandations de sécurité d'Express mais ils nécessitaient quelques ajustements côté frontend

## Environnement de développement

#### 

- Visual Studio Code
- Node / Sass / Npm
- Nodemon
- Express
- Mongo DB / Mongo Atlas / Mongoose

#### Pour en savoir plus sur la sécurité informatique (développement/production/utilisation):

- [Framework Express: meilleures pratiques en production](https://expressjs.com/fr/advanced/best-practice-security.html)
- [GitHub Advisory Database](https://github.com/advisories)
- [OWASP Top 10 Web Application Security Risks](https://owasp.org/www-project-top-ten/)